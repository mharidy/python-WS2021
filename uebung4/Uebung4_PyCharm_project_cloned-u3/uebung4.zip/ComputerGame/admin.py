from django.contrib import admin
from ComputerGame.models import ComputerGame

# Register your models here.
admin.site.register(ComputerGame)
