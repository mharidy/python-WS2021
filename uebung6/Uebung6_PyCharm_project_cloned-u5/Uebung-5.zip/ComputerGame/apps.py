from django.apps import AppConfig


class ComputergameConfig(AppConfig):
    name = 'ComputerGame'
