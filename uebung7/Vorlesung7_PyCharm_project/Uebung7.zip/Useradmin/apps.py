from django.apps import AppConfig


class UseradminConfig(AppConfig):
    name = 'Useradmin'
