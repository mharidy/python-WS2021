from django.apps import AppConfig


class ComputersConfig(AppConfig):
    name = 'Computers'
