from django.contrib import admin
from Books.models import Book

# Register your models here.
admin.site.register(Book)